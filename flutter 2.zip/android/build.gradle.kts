// android/build.gradle.kts (Project-level)
// android/build.gradle.kts (Project-level)

// android/build.gradle.kts (Project-level)

plugins {
    // Android Gradle Plugin ka zaroori version
    id("com.android.application") version "8.7.3" apply false

    // Kotlin Plugin ka compatible version
    id("org.jetbrains.kotlin.android") version "2.1.0" apply false

    // Baaki plugins wese hi rehne dein
  
    id("com.google.gms.google-services") version "4.4.2" apply false
}



allprojects {
    repositories {
        google()
        mavenCentral()
    }

   
}

val newBuildDir: Directory = rootProject.layout.buildDirectory.dir("../../build").get()
rootProject.layout.buildDirectory.value(newBuildDir)

subprojects {
    val newSubprojectBuildDir: Directory = newBuildDir.dir(project.name)
    project.layout.buildDirectory.value(newSubprojectBuildDir)
}
subprojects {
    project.evaluationDependsOn(":app")}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}